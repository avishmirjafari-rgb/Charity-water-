# Make Waves — charity: water Student Landing Page

This beginner-friendly landing page is built with **HTML and CSS only**. It is a student campaign concept, not an official charity: water website.

## Files

- `index.html` — page structure and text
- `style.css` — colors, layout, animations, and mobile responsiveness
- `img/clean-water-hero.jpg` — hero image used in the original concept

## How to use in GitHub Codespaces

1. Open the **starter Codespace** from your assignment.
2. Upload the files from this folder to the **top-level of the repository**. If the starter repository already has an `index.html` and `style.css`, you can replace their contents with these versions. Upload the `img` folder with the image inside it.
3. Make sure `index.html`, `style.css`, and `img/` are in the same top-level folder (unless your starter has a different intended publishing directory).
4. Preview the page in Codespaces, for example using the starter's preview tool or a Live Server extension. Check both desktop and mobile width.
5. In the Codespaces terminal, run:

   ```bash
   git add .
   git commit -m "Build responsive charity water landing page"
   git push
   ```

6. In the **GitHub repository**, go to **Settings → Pages**. Choose **Deploy from a branch**, select the branch you pushed (typically `main`), select `/ (root)`, and click **Save**.
7. Wait for GitHub Pages to publish your site. Open its Pages URL to test it. It usually looks like `https://USERNAME.github.io/REPOSITORY-NAME/`.
8. Submit **the live Pages URL**, not your repository or Codespace link.

## Customization

- Edit the words in `index.html`.
- Change the color variables at the top of `style.css`.
- Replace `img/clean-water-hero.jpg` with your selected campaign photograph and update the image's `alt` text if needed.

**Important:** This template uses charity: water's real donation website for its donate buttons. It does not process payments or collect personal information.
